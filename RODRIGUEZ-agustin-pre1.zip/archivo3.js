

const productos = [
                    {id: 1 ,nombre: "Naranja", precio: 50, categoria:"fruta,suelto"},
                    {id: 2 ,nombre: "Manzana", precio: 60,categoria:"fruta,suelto"},
                    {id: 3 ,nombre: "Banana", precio: 70,categoria:"fruta,suelto"},
                    {id: 4 ,nombre: "Acelga", precio: 80,categoria:"verdura,suelto"},
                    {id: 5 ,nombre: "Bolson de Frutas", precio: 100,categoria:"fruta,bolson"},
                    {id: 6 ,nombre: "Bolson de Verduras", precio: 120,categoria:"verdura,bolson"},
                    {id: 7 ,nombre: "Bolson Mixto", precio: 250,categoria:"fruta,verdura,bolson"},
                    {id: 8 ,nombre: "Bolson Eco", precio: 300,categoria:"fruta,verdura,bolson"},
                    {id: 9 ,nombre: "Rabanito", precio: 500,categoria:"verdura,suelto"},
            
                  ];


let nuevaLista = new Array ();
let listaProductos = new Array ();
let carrito =[];
let acumulado = 0 ;




let categoria =  prompt("Introduzca una categoria > fruta,verdura,bolson,suelto o todos")

function filtroEspecifico (categoria)

{   for (const producto of categoria)
  {   console.log("Articulo:"+producto.id +" Producto:" + producto.nombre + " Precio:$" + producto.precio);

  }  
  let artElegido =  prompt("Elige el articulo deseado");
  
    
    while (artElegido!=0){
    const artEncontrado = productos.filter((producto)=>producto.id == artElegido);
   
    carrito.push(artEncontrado);
    for (const producto of artEncontrado)
    {   console.log("Has elegido>> Articulo:"+producto.id + " Producto:" + producto.nombre + " Precio:$" + producto.precio);
    
    acumulado = producto.precio + acumulado;
      
    } 
    artElegido =  prompt("Elige el articulo deseado, elige 0(cero) para finalizar la compra");
  }




}




if (categoria != "todos") {
            
              listaFiltrada = productos.filter((producto)=>producto.categoria.includes(categoria));
              filtroEspecifico (listaFiltrada);
            
            }         else{ filtroEspecifico(productos);
                          }
                      
                  console.log("Monto Total en $: "+ acumulado);






